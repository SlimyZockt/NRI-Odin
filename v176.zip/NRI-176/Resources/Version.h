// © 2021 NVIDIA Corporation

#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)

#define VERSION 176

#define VERSION_STRING STR(VERSION)
